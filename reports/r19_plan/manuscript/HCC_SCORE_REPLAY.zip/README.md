# Adult HCC score replay for internal review

The replay covers the four absolute and within-pool Table 1 comparisons in adult JHH-5 and JHH-7. It uses the previously evaluated 10 µM, 24-hour CMap cohorts. The export rechecks both frozen model lineups and their score receipts on the original server before calculating compact per-parent score statistics. Each row contains an ordinal ID, physical well count, target contrast energy and six models' error summaries. The files carry no compound names, gene-level values, well identifiers or sample-level predictions.

The local replay recalculates the candidate, metric-specific best of five public adaptations, paired differences, 99% intervals and best-reference frequencies. It uses the original parent order, seed 150104 and 10,000 resamples. Within-pool centering and membership are fixed in the exported statistics. The scope is verification of statistical aggregation from those statistics. Raw data processing, prediction training, retrieval, the time-transfer analyses and independent experimental confirmation use separate evidence. The exported files are for internal review pending the release decision. [Manuscript table](table1.tsv)

## Re-run the four comparisons

Use Python 3.10 or later and NumPy 2.2.6.

```bash
python -m pip install -r requirements.txt
python -I replay_adult_hcc.py --packet . --out replayed
```

The script prints one verification line per comparison and writes two tables in the new output directory. Exactly matching best-model counts and absolute numeric agreement within 1e-12 of the recorded output are required.
